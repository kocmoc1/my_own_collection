# Ansible Collection - my_own_namespace.yandex_cloud_elk

Documentation for the collection.

role-pb.yml Плейбук для роли
single-task-pb.yml Плейбук из одного таска

plugins/modules/my_own_module.py - Модуль создания файла.